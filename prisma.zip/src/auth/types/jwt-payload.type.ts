export type JwtPayload = {
  email: string;
  sub: number;
};
