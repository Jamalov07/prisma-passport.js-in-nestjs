export class AuthDto {
    
  readonly email: string;
  readonly password: string;
}
